<?php
include('config.php');
$sql = 'SELECT * FROM upload ORDER BY id DESC';
$result = mysqli_query($conn, $sql);
if (!$result) {
    die('Could not get data: ' . mysqli_error($conn));
}
echo "<p><h1>Data File</h1></p>";
echo "<p><a href='index.php'>Tambah Data</a></p>";
echo "<table width = '850' border='1'>
<tr>
<td>No</td>
<td>Nama File</td>
<td>Deskripsi</td>
<td>Tanggal Upload</td>
<td colspan='2'>Aksi</td>
</tr>";
$i = 1;
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td> $i </td>";
    echo "<td> {$row['nama_file']} </td>";
    echo "<td> {$row['deskripsi']} </td>";
    echo "<td> {$row['tgl_upload']} </td>";
    echo "<td> <a href='download.php?file_name={$row['nama_file']}'>
    Download </a></td>";
    echo "<td> <a href='delete.php?id_file={$row['id']}&filename={$row['nama_file']}'> Delete </a></td>";
    echo "</tr>";
    $i++;
}
echo "</table>";
mysqli_close($conn);
?>